export function News() {
  return (
    <div className="py-20 bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">お知らせ</h1>
        <p className="text-slate-600 mb-12">News & Updates</p>

        <div className="space-y-6">
          {/* ↓ 新しいお知らせを追加する場合は、このフォーマットをコピーして使用してください */}
          {/*
          <div className="border-b border-slate-200 pb-6 group cursor-pointer">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="text-sm font-mono text-slate-500">YYYY.MM.DD</span>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                カテゴリ名
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
              タイトルのテキスト
            </h2>
            <p className="text-slate-600 text-sm line-clamp-2">
              お知らせの本文のテキストをここに入力します。
            </p>
          </div>
          */}
          
          <div className="border-b border-slate-200 pb-6 group cursor-pointer">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="text-sm font-mono text-slate-500">2026.07.01</span>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                お知らせ
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
              webサイト開設のお知らせ
            </h2>
            <p className="text-slate-600 text-sm line-clamp-2">
              当チームの公式ウェブサイトを開設いたしました。今後の活動報告や大会成績など、随時更新してまいります。
            </p>
          </div>
          <div className="border-b border-slate-200 pb-6 group cursor-pointer">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <span className="text-sm font-mono text-slate-500">2026.05.20</span>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                お知らせ
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
              サークル創立のお知らせ
            </h2>
            <p className="text-slate-600 text-sm line-clamp-2">
              JAISTフォーミュラ研究会が正式に発足いたしました。学生フォーミュラ大会への出場を目指し、活動を開始します。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

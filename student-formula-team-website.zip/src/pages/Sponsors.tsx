import { Briefcase, HeartHandshake, Landmark } from 'lucide-react';

export function Sponsors() {
  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">スポンサー</h1>
        <p className="text-slate-600 mb-12">Sponsors</p>

        {/* Recruitment Message */}
        <section className="bg-white text-slate-900 p-8 md:p-12 rounded-3xl shadow-sm border border-slate-200 mb-16 relative overflow-hidden">
          <div className="absolute -top-24 -right-24 text-slate-50">
            <HeartHandshake size={300} />
          </div>
          <div className="relative z-10 max-w-3xl">
            <h2 className="text-2xl md:text-3xl font-bold mb-6">スポンサー様を募集しています</h2>
            <div className="space-y-4 text-slate-600">
              <p>
                当チームは「実践的なものづくりを通じたエンジニア育成」を理念に掲げ活動しております。
                しかし、ゼロからの製作にあたり、特に「各種パーツの物品提供」や「技術・加工支援」が不足しております。
                
              </p>

              <p>
                この活動にご賛同いただき、我々をご支援していただけるスポンサー様を法人・個人を問わず募集しております。ご関心をお持ちいただけましたら、ご連絡いただければ幸いです。 
              </p>

              
            </div>
            
            {/* ↓ スポンサー要項pdf作ったらここに配置 */}
            {/*
            <div className="mt-8 flex flex-wrap gap-4">
              <a href="/contact" className="inline-block bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors shadow-md">
                協賛についてのお問い合わせ
              </a>
              <button className="inline-block bg-white text-slate-700 border border-slate-300 font-bold py-3 px-6 rounded-lg hover:bg-slate-50 transition-colors">
                スポンサー要項のダウンロード (PDF)
              </button>
            </div>
            */}
          </div>
        </section>

        {/* ↓ 寄付の準備ができたら以下のコメントアウトを外して表示してください */}
        {/* Donation Message
        <section className="bg-slate-100 text-slate-900 p-8 md:p-12 rounded-3xl mb-16 relative">
          <div className="flex items-center gap-3 mb-6">
            <Landmark className="text-slate-700" size={32} />
            <h2 className="text-2xl md:text-3xl font-bold">個人の皆様からのご寄付のお願い</h2>
          </div>
          <div className="max-w-3xl">
            <div className="space-y-4 text-slate-700 mb-8">
              <p>
                JAISTフォーミュラ研究会では、個人の皆様からのご支援も受け付けております。
                皆様からいただいたご寄付は、車両製作費や大会参加のための遠征費として、大切に活用させていただきます。
              </p>
              <p>
                少額からでも大歓迎です。学生の挑戦を応援していただける方のご支援を心よりお待ちしております。
              </p>
            </div>
            
            <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-lg mb-4 text-slate-900 border-b border-slate-100 pb-3">お振込先口座</h3>
              <div className="space-y-4 text-slate-600">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-1 md:gap-4 items-center">
                  <div className="text-sm font-medium text-slate-500">金融機関名</div>
                  <div className="md:col-span-3 font-semibold text-slate-900 text-lg">○○銀行 ○○支店</div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-1 md:gap-4 items-center">
                  <div className="text-sm font-medium text-slate-500">口座種別・番号</div>
                  <div className="md:col-span-3 font-semibold text-slate-900 text-lg">普通 1234567</div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-1 md:gap-4 items-center">
                  <div className="text-sm font-medium text-slate-500">口座名義</div>
                  <div className="md:col-span-3 font-semibold text-slate-900 text-lg">ジャイストフォーミュラケンキュウカイ</div>
                </div>
              </div>
              <div className="mt-6 text-sm text-slate-500 bg-slate-50 p-4 rounded-xl border border-slate-100">
                ※ お振込みに関するお問い合わせは、<a href="/contact" className="text-blue-600 hover:underline font-medium">お問い合わせページ</a>よりお願いいたします。<br />
                ※ 領収書の発行をご希望の場合は、お振込み前にご相談ください。
              </div>
            </div>
          </div>
        </section>
        */}

        {/* Sponsor List / Logos */}
        <section>
          <div className="flex items-center gap-3 mb-8 border-b border-slate-200 pb-4">
            <Briefcase className="text-slate-600" size={32} />
            <h2 className="text-2xl font-bold text-slate-900">スポンサー様一覧</h2>
          </div>
          {/* ↓ スポンサーが決まったら以下のコメントアウトを外して表示してください */}
          {/*
          <p className="text-slate-600 mb-8">
            日頃より当チームの活動にご支援・ご協力を賜り、厚く御礼申し上げます。（順不同・敬称略）
          </p>

          <div className="space-y-6">
            
            // スポンサーを追加する際はこちらの配列にデータを追加してください。
            // 例: { id: 1, name: '〇〇株式会社', url: 'https://example.com', logo: '/images/sponsors/logo.png' }
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { id: 1, name: '〇〇株式会社', url: '#', logo: null },
                { id: 2, name: '〇〇株式会社', url: '#', logo: null },
                { id: 3, name: '〇〇株式会社', url: '#', logo: null },
                { id: 4, name: '〇〇株式会社', url: '#', logo: null },
                { id: 5, name: '〇〇株式会社', url: '#', logo: null },
                { id: 6, name: '〇〇株式会社', url: '#', logo: null },
              ].map(sponsor => (
                <div key={sponsor.id} className="flex flex-col items-center">
                  <a 
                    href={sponsor.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="w-full bg-white h-40 rounded-xl flex items-center justify-center border border-slate-200 shadow-sm p-6 hover:shadow-md transition-shadow mb-3"
                  >
                    {sponsor.logo ? (
                      <img src={sponsor.logo} alt={`${sponsor.name} ロゴ`} className="max-w-full max-h-full object-contain" />
                    ) : (
                      <span className="text-slate-300 font-bold text-xl">LOGO</span>
                    )}
                  </a>
                  <a 
                    href={sponsor.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="font-bold text-slate-700 hover:text-blue-600 hover:underline transition-colors text-center"
                  >
                    {sponsor.name}
                  </a>
                </div>
              ))}
            </div>
          </div>
          */}
        </section>

      </div>
    </div>
  );
}

import { Wrench } from 'lucide-react';

export function Results() {
  return (
    <div className="py-20 bg-white min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">マシン紹介</h1>
        <p className="text-slate-600 mb-12">Machine Info</p>

        {/* Machine Info */}
        <section>
          <div className="flex items-center gap-3 mb-8 border-b border-slate-200 pb-4">
            <Wrench className="text-slate-600" size={32} />
            <h2 className="text-2xl font-bold text-slate-900">2026年度</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* 2025 Machine */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden group">
              <div className="aspect-[4/3] bg-slate-200 relative overflow-hidden">
                {/* Placeholder Image */}
                <img 
                  src="https://images.unsplash.com/photo-1595180631623-e4d0faaf6803?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="2026 Machine" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3">2026年度マシン（仮）</h3>
                <p className="text-sm text-slate-600 mb-4 line-clamp-3">
                  鋭意製作中
                </p>
              </div>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}

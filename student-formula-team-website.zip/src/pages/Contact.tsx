import { Mail, Instagram, ExternalLink } from 'lucide-react';

const XIcon = ({ size = 24, className = "" }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
  >
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
  </svg>
);

export function Contact() {
  return (
    <div className="py-20 bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">お問い合わせ</h1>
        <p className="text-slate-600 mb-12">Contact Us</p>

        <div className="grid md:grid-cols-2 gap-12">
          
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold text-slate-900 mb-4">連絡先</h2>
              <p className="text-slate-600 mb-4">
                新入生の入部相談、スポンサーシップに関するお問い合わせなどは、以下のアドレスまでお気軽にご連絡ください。
              </p>
              <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg border border-slate-100">
                <Mail className="text-blue-600" size={24} />
                <a href="mailto:jaist.formula@gmail.com" className="text-lg font-mono text-slate-800 hover:text-blue-600 transition-colors">
                  jaist.formula＠gmail.com
                </a>
              </div>
              <p className="text-sm text-slate-500 mt-2">
                ※スパム対策のため「@」を全角で表記しています。送信の際は半角に直してください。
              </p>
            </div>

            <div>
              <h2 className="text-xl font-bold text-slate-900 mb-4">SNSリンク</h2>
              <div className="space-y-3">
                <a href="https://x.com/jaistformula" target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100 hover:bg-slate-100 transition-colors group">
                  <div className="flex items-center gap-3">
                    <XIcon className="text-slate-900" size={24} />
                    <span className="font-bold text-slate-700">X</span>
                  </div>
                  <ExternalLink size={18} className="text-slate-400 group-hover:text-slate-600" />
                </a>
                <a href="https://www.instagram.com/jaist.formula?igsh=cmNvZjI2MGs2b2p5" target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100 hover:bg-slate-100 transition-colors group">
                  <div className="flex items-center gap-3">
                    <Instagram className="text-[#E1306C]" size={24} />
                    <span className="font-bold text-slate-700">Instagram</span>
                  </div>
                  <ExternalLink size={18} className="text-slate-400 group-hover:text-slate-600" />
                </a>
              </div>
            </div>
          </div>

          {/*↓活動場所入れるとこ*/}
          {/* Map/Location (Optional styling)
          <div className="bg-slate-100 rounded-2xl p-8 flex flex-col justify-center items-center text-center">
            <h3 className="font-bold text-slate-900 mb-2">活動場所（ガレージ）</h3>
            <p className="text-slate-600 text-sm mb-6">
              〇〇大学 〇〇キャンパス<br />
              工作センター横 第1ガレージ
            </p>
            <div className="w-full aspect-square bg-slate-200 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400">
              [ キャンパスマップ埋め込み ]
            </div>
          </div>
          */}
          
        </div>
      </div>
    </div>
  );
}

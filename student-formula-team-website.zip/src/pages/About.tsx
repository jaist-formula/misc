import { Users, Crosshair } from 'lucide-react';

export function About() {
  return (
    <div className="py-20 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">チーム紹介</h1>
        <p className="text-slate-600 mb-12">About Us</p>

        {/* Club Introduction */}
        <section className="bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-slate-200 mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Users className="text-blue-600" size={32} />
            <h2 className="text-2xl font-bold text-slate-900">チーム紹介</h2>
          </div>
          <div className="prose prose-slate max-w-none text-slate-600">
            <p>
              私達JAISTフォーミュラ研究会は北陸先端科学技術大学院大学(JAIST)に所属する学生により2026年5月に新設されたJAIST公認のサークルです。
              2027年に開催される学生フォーミュラ日本大会への出場を目標に掲げ、車両の設計・開発やチーム運営に取り組み、その過程を通じて実践的なものづくりや、プロジェクトマネジメントを学ぶことを目的に日々活動しています。
            </p>
            
          </div>
        </section>

        {/* Activity Info */}
        <section className="bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <Crosshair className="text-blue-600" size={32} />
            <h2 className="text-2xl font-bold text-slate-900">活動情報</h2>
          </div>
          
          <dl className="divide-y divide-slate-100">
            <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <dt className="font-bold text-slate-900">活動日時</dt>
              <dd className="md:col-span-2 text-slate-600">週1回のミーティング＋ 各自のペースで作業</dd>
            </div>
            <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <dt className="font-bold text-slate-900">活動場所</dt>
              <dd className="md:col-span-2 text-slate-600">都度決定</dd>
            </div>
            <div className="py-4 grid grid-cols-1 md:grid-cols-3 gap-4">
              <dt className="font-bold text-slate-900">メンバー数</dt>
              <dd className="md:col-span-2 text-slate-600">約15名 </dd>
            </div>
          </dl>
        </section>

      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Wrench, Users, Trophy, Flag, ChevronRight } from 'lucide-react';

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 text-white flex items-center justify-center min-h-[85vh]">
        {/* Placeholder for background image */}
        <div className="absolute inset-0 opacity-40">
          <img 
            src={`${import.meta.env.BASE_URL}logo.jpg`} 
            alt="JAIST フォーミュラ研究会 ロゴ" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-sm font-medium mb-6">
              <span className="flex h-2 w-2 rounded-full bg-blue-500"></span>
              学生フォーミュラ 2027年大会参戦予定！
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
                JAIST<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                フォーミュラ研究会
              </span>
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-xl leading-relaxed">
              JAISTフォーミュラ研究会は学生フォーミュラ日本大会に向けて活動している北陸先端科学技術大学院大学(JAIST)の公認サークルです。
              
              
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/about" 
                className="inline-flex justify-center items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-lg transition-all shadow-lg hover:shadow-blue-500/25"
              >
                サークルについて <ArrowRight size={20} />
              </Link>
              <Link 
                to="/contact" 
                className="inline-flex justify-center items-center gap-2 bg-white/10 hover:bg-white/20 text-white font-medium py-3 px-8 rounded-lg backdrop-blur-sm transition-all border border-white/10"
              >
                お問い合わせ
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Feature Section (Welcoming & Professional) */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">
              大学院大学初の学生フォーミュラチーム
            </h2>
            <p className="text-slate-600">
              
              私たちは「大学院大学初」のフォーミュラチームです。修士課程を基本とするため、メンバーに与えられた活動期間はわずか2年しかありません。
              この短いサイクルで複雑なマシンを完成させるには、個人の技術だけでなく、徹底したスケジュール管理、効率的なタスク分配、そして確実な技術継承の仕組みが不可欠です。
              限られた2年間を全力で駆け抜けながらも、次世代へと確実にバトンを繋ぐ強固なチームを創り上げます。

            </p>
          </div>

          {/*
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-6">
                <Wrench size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">ゼロから創る</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                CADでの設計、鋼管の溶接、カーボンパーツの製作まで。ただ部品を組み立てるのではなく、理論に基づき一からマシンを創り上げます。
              </p>
            </div>
            
            <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center mb-6">
                <Users size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">多様なメンバー</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                工学部だけでなく、文系学部の学生も広報やスポンサー渉外、会計などで大活躍しています。車好きでなくても、それぞれの得意分野を活かせます。
              </p>
            </div>
            
            <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 hover:shadow-md transition-shadow">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-6">
                <Flag size={28} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">全国への挑戦</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                年に一度行われる全日本学生フォーミュラ大会に出場。全国の強豪校と競い合い、ものづくりの真の価値と自分たちの成長の証をコースに刻みます。
              </p>
            </div>
          </div>
          */}
        </div>
      </section>

      {/* Latest News & CTA Section - Flex Layout */}
      <section className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-12">
            
            {/* News */}
            <div className="flex-1">
              <div className="flex justify-between items-end mb-6">
                <h2 className="text-2xl font-bold text-slate-900">最新のお知らせ</h2>
                <Link to="/news" className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-1">
                  一覧を見る <ArrowRight size={16} />
                </Link>
              </div>
              
              <div className="space-y-4">
                {[
                  { date: '2026.07.01', category: 'お知らせ', title: 'webサイト開設のお知らせ', isNew: true },
                  { date: '2026.05.20', category: 'お知らせ', title: 'サークル創立のお知らせ', isNew: false }
                ].map((news, idx) => (
                  <Link key={idx} to="/news" className="group block bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-300 transition-colors shadow-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-mono text-slate-500">{news.date}</span>
                      <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{news.category}</span>
                      {news.isNew && <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-600 animate-pulse">NEW</span>}
                    </div>
                    <h3 className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                      {news.title}
                    </h3>
                  </Link>
                ))}
              </div>
            </div>

            {/* CTA Blocks */}
            <div className="lg:w-1/3 flex flex-col gap-6">
              
              {/* Member Recruitment CTA */}
              <div className="bg-white rounded-2xl p-8 text-slate-900 flex-1 flex flex-col justify-between shadow-sm border border-slate-200 relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-xl font-bold mb-3">メンバー募集中！</h3>
                  <p className="text-slate-600 text-sm leading-relaxed mb-6">
                    新入生・在学生問わず、新しい仲間を募集しています。車づくりに興味がある方はぜひご連絡ください。
                  </p>
                </div>
                <Link 
                  to="/contact" 
                  className="relative z-10 bg-slate-900 text-white hover:bg-slate-800 font-bold py-3 px-4 rounded-lg text-center transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  お問い合わせ <ChevronRight size={18} />
                </Link>
              </div>

              {/* Sponsor CTA Block */}
              <div className="bg-white rounded-2xl p-8 text-slate-900 flex-1 flex flex-col justify-between shadow-sm border border-slate-200 relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-8 -mr-8 text-slate-50">
                  <Trophy size={160} />
                </div>
                <div className="relative z-10 mb-6">
                  <h3 className="text-xl font-bold">スポンサー情報</h3>
                </div>
                <Link 
                  to="/sponsors" 
                  className="relative z-10 bg-slate-900 text-white hover:bg-slate-800 font-bold py-3 px-4 rounded-lg text-center transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  スポンサー一覧を見る <ChevronRight size={18} />
                </Link>
              </div>
            </div>
            
          </div>

          {/* ↓ SNS埋め込み用スペース時間あったらやる */}
          {/* SNS Feed Section
          <div className="mt-16 bg-white p-8 rounded-xl border border-slate-200 text-center shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 mb-2">SNSで最新情報をチェック！</h3>
            <p className="text-slate-600 text-sm mb-6">公式X やInstagramで日々の活動を発信しています。</p>
            <div className="h-64 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-400">
              [ X タイムライン埋め込みエリア ]
            </div>
          </div>
          */}
        </div>
      </section>
    </div>
  );
}

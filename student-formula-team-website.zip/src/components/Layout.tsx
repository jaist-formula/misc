import { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { Menu, X, CarFront, ChevronRight, Instagram } from 'lucide-react';

export function Layout() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'ホーム', path: '/' },
    { name: 'お知らせ', path: '/news' },
    { name: 'チーム紹介', path: '/about' },
    { name: 'マシン紹介', path: '/results' },
    { name: 'スポンサー', path: '/sponsors' },
    { name: 'お問い合わせ', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-2 group py-1">
                <img src={`${import.meta.env.BASE_URL}logo.jpg`} alt="JAISTフォーミュラ研究会 ロゴ" className="h-[70px] w-[240px] md:w-[300px] object-contain object-left rounded-md" />
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive(link.path)
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-slate-500 hover:bg-slate-100 p-2 rounded-md focus:outline-none"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive(link.path)
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <img src={`${import.meta.env.BASE_URL}logo.jpg`} alt="JAISTフォーミュラ研究会 ロゴ" className="h-8 w-auto object-contain rounded-md" />
                <span className="font-bold text-xl text-white">JAISTフォーミュラ研究会</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">リンク</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/news" className="hover:text-blue-400 transition-colors flex items-center gap-1"><ChevronRight size={14}/> お知らせ</Link></li>
                <li><Link to="/about" className="hover:text-blue-400 transition-colors flex items-center gap-1"><ChevronRight size={14}/> チーム紹介</Link></li>
                <li><Link to="/results" className="hover:text-blue-400 transition-colors flex items-center gap-1"><ChevronRight size={14}/> マシン紹介</Link></li>
                <li><Link to="/sponsors" className="hover:text-blue-400 transition-colors flex items-center gap-1"><ChevronRight size={14}/> スポンサー</Link></li>
                <li><Link to="/contact" className="hover:text-blue-400 transition-colors flex items-center gap-1"><ChevronRight size={14}/> お問い合わせ</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-4">公式SNS</h3>
              <div className="flex items-center gap-4">
                <a href="https://x.com/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-slate-100 transition-colors">
                  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
                  <span className="sr-only">X (Twitter)</span>
                </a>
                <a href="https://instagram.com/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-pink-500 transition-colors">
                  <Instagram size={24} />
                  <span className="sr-only">Instagram</span>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-slate-800 mt-12 pt-8 text-sm text-center">
            <p>&copy; {new Date().getFullYear()} JAISTフォーミュラ研究会. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
